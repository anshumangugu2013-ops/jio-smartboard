Place optional icons and images here in later phases.
