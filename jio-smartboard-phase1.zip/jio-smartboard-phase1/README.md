# Jio SmartBoard — Phase 1 Foundation

A static, TV-first SmartBoard website foundation for a Jio Set-Top Box connected to a television, with a mobile remote interface preview.

## Included in Phase 1
- Responsive landing dashboard
- TV workspace with remote-friendly navigation
- Local digital whiteboard (mouse/touch pointer drawing)
- Mobile remote preview with Touchpad, Drawing Pad and Keyboard tabs
- Browser capability diagnostics
- Fullscreen request button
- Basic PWA manifest and service worker
- No backend credentials or private keys

## Not enabled yet
- Phone-to-TV live pairing
- Firebase authentication or real-time control
- Cloud document synchronisation
- PDF/PPT presentation engine
- Persistent whiteboard saving

These are later phases. The mobile controls in this version are previews and do not send commands to the TV.

## Run locally
Use a local static web server. For example, with Python installed:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Deploy to GitHub Pages
1. Create a public GitHub repository named `jio-smartboard` (or another name you choose).
2. Upload all files in this folder to the repository root.
3. In repository Settings → Pages, choose Deploy from a branch.
4. Select `main` and `/ (root)`, then Save.
5. Open the published GitHub Pages URL.

## Routes
- Home: `./`
- TV workspace: `./?mode=tv`
- Mobile remote preview: `./?mode=remote`

## First hardware test
Open the home page on the Jio Set-Top Box browser and select **Run compatibility check**. Record the results, and also test:
- Arrow keys and OK on the Jio remote
- Back/Escape behaviour
- Fullscreen button
- Whiteboard drawing with any connected mouse/touch pointer
- Landscape and portrait layout on your phone

## Important
A website cannot make a standard TV touchscreen. The phone will become the input device after the live pairing and synchronisation phases are implemented. A browser compatibility result is only a capability check; it does not guarantee every feature works correctly on the specific Jio firmware.
