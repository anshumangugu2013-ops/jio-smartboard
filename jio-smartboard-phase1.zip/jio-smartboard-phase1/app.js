(() => {
  "use strict";
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const views = {home:$("#homeView"), tv:$("#tvView"), remote:$("#remoteView")};
  const params = new URLSearchParams(location.search);
  const mode = params.get("mode") || "home";
  Object.entries(views).forEach(([name, el]) => el.classList.toggle("hidden", name !== (views[mode] ? mode : "home")));

  const toast = (message) => {
    const el = $("#toast"); if (!el) return;
    el.textContent = message; el.classList.add("show");
    clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2300);
  };

  // About dialog
  const dialog = $("#aboutDialog");
  $("#helpButton")?.addEventListener("click", () => dialog?.showModal());
  $("#closeDialog")?.addEventListener("click", () => dialog?.close());
  $("#dialogOk")?.addEventListener("click", () => dialog?.close());

  // Browser capability check — run this on the Jio TV browser.
  $("#runDiagnostics")?.addEventListener("click", () => {
    const tests = [
      ["JavaScript", typeof window !== "undefined"],
      ["HTML Canvas", !!document.createElement("canvas").getContext],
      ["Local storage", (() => { try { localStorage.setItem("_jio_test","1"); localStorage.removeItem("_jio_test"); return true; } catch(e) { return false; } })()],
      ["IndexedDB", "indexedDB" in window],
      ["Fullscreen API", !!document.documentElement.requestFullscreen],
      ["Service Worker", "serviceWorker" in navigator],
      ["WebSocket", "WebSocket" in window],
      ["Touch events", "ontouchstart" in window || navigator.maxTouchPoints > 0]
    ];
    $("#diagnostics").innerHTML = tests.map(([name, ok]) =>
      `<div class="diag-row"><span>${name}</span><b class="${ok ? "diag-ok" : "diag-no"}">${ok ? "SUPPORTED" : "NOT DETECTED"}</b></div>`
    ).join("");
    toast("Browser compatibility check completed.");
  });

  // TV workspace navigation
  $$(".side-link").forEach(btn => btn.addEventListener("click", () => {
    $$(".side-link").forEach(b => b.classList.toggle("active", b === btn));
    $$(".panel").forEach(panel => panel.classList.toggle("hidden", panel.id !== btn.dataset.panel));
  }));
  $("#fullscreenButton")?.addEventListener("click", async () => {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
      else await document.exitFullscreen();
    } catch (e) { toast("Fullscreen is not available in this browser."); }
  });

  // TV whiteboard: pointer, mouse and touch drawing.
  const canvas = $("#boardCanvas");
  if (canvas) {
    const ctx = canvas.getContext("2d");
    let drawing = false, tool = "pen", last = null;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const old = document.createElement("canvas");
      old.width = canvas.width; old.height = canvas.height;
      old.getContext("2d").drawImage(canvas, 0, 0);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, Math.round(rect.width*dpr));
      canvas.height = Math.max(1, Math.round(rect.height*dpr));
      ctx.setTransform(dpr,0,0,dpr,0,0);
      ctx.lineCap = "round"; ctx.lineJoin = "round";
      if (old.width && old.height) ctx.drawImage(old,0,0,old.width,old.height,0,0,rect.width,rect.height);
    };
    const point = e => { const r=canvas.getBoundingClientRect(); return {x:e.clientX-r.left,y:e.clientY-r.top}; };
    canvas.addEventListener("pointerdown", e => { drawing=true; last=point(e); canvas.setPointerCapture?.(e.pointerId); $("#boardHint").style.opacity="0"; });
    canvas.addEventListener("pointermove", e => {
      if (!drawing) return; const p=point(e);
      ctx.beginPath(); ctx.moveTo(last.x,last.y); ctx.lineTo(p.x,p.y);
      ctx.strokeStyle = tool==="eraser" ? "#f8fafc" : "#172b45";
      ctx.lineWidth = tool==="eraser" ? 24 : 3; ctx.stroke(); last=p;
    });
    ["pointerup","pointercancel","pointerleave"].forEach(ev => canvas.addEventListener(ev, () => { drawing=false; last=null; }));
    $$(".tool-button[data-tool]").forEach(btn => btn.addEventListener("click", () => {
      tool=btn.dataset.tool; $$(".tool-button[data-tool]").forEach(b=>b.classList.toggle("active",b===btn));
      $("#boardStatus").textContent = tool==="pen" ? "Pen selected" : "Eraser selected";
    }));
    $("#clearBoard")?.addEventListener("click", () => { ctx.clearRect(0,0,canvas.width,canvas.height); $("#boardHint").style.opacity="1"; $("#boardStatus").textContent="Canvas cleared"; });
    if ("ResizeObserver" in window) new ResizeObserver(resize).observe(canvas.parentElement); else window.addEventListener("resize",resize);
    requestAnimationFrame(resize);
  }

  // Mobile remote tab previews.
  $$(".remote-tab").forEach(btn => btn.addEventListener("click", () => {
    $$(".remote-tab").forEach(b=>b.classList.toggle("active",b===btn));
    ["touch","draw","keys"].forEach(name => $("#"+name+"Remote").classList.toggle("hidden", name!==btn.dataset.remote));
    if (btn.dataset.remote==="draw") resizeRemoteCanvas();
  }));
  const touchpad=$("#touchpad");
  touchpad?.addEventListener("pointermove", e => {
    if (!(e.buttons || e.pressure)) return;
    const r=touchpad.getBoundingClientRect(), x=Math.round((e.clientX-r.left)/r.width*100), y=Math.round((e.clientY-r.top)/r.height*100);
    $("#touchCoordinates").textContent=`X: ${x} · Y: ${y}`;
  });
  $$("[data-key]").forEach(btn=>btn.addEventListener("click",()=>toast(`${btn.dataset.key.toUpperCase()} control preview — pairing not active.`)));

  // Mobile drawing pad preview.
  const remoteCanvas=$("#remoteCanvas");
  let remoteCtx, remoteDrawing=false, remoteLast=null, remoteErase=false;
  function resizeRemoteCanvas(){
    if(!remoteCanvas) return;
    const rect=remoteCanvas.getBoundingClientRect(), dpr=Math.min(window.devicePixelRatio||1,2);
    const snapshot=document.createElement("canvas"); snapshot.width=remoteCanvas.width; snapshot.height=remoteCanvas.height;
    if(remoteCanvas.width) snapshot.getContext("2d").drawImage(remoteCanvas,0,0);
    remoteCanvas.width=Math.max(1,Math.round(rect.width*dpr)); remoteCanvas.height=Math.max(1,Math.round(rect.height*dpr));
    remoteCtx=remoteCanvas.getContext("2d"); remoteCtx.setTransform(dpr,0,0,dpr,0,0); remoteCtx.lineCap="round"; remoteCtx.lineJoin="round";
    if(snapshot.width) remoteCtx.drawImage(snapshot,0,0,snapshot.width,snapshot.height,0,0,rect.width,rect.height);
  }
  if(remoteCanvas){
    remoteCanvas.addEventListener("pointerdown",e=>{remoteDrawing=true;const r=remoteCanvas.getBoundingClientRect();remoteLast={x:e.clientX-r.left,y:e.clientY-r.top};remoteCanvas.setPointerCapture?.(e.pointerId);});
    remoteCanvas.addEventListener("pointermove",e=>{if(!remoteDrawing)return;const r=remoteCanvas.getBoundingClientRect(),p={x:e.clientX-r.left,y:e.clientY-r.top};remoteCtx.beginPath();remoteCtx.moveTo(remoteLast.x,remoteLast.y);remoteCtx.lineTo(p.x,p.y);remoteCtx.strokeStyle=remoteErase?"#f8fafc":$("#remoteColor").value;remoteCtx.lineWidth=remoteErase?22:3;remoteCtx.stroke();remoteLast=p;});
    ["pointerup","pointercancel","pointerleave"].forEach(ev=>remoteCanvas.addEventListener(ev,()=>{remoteDrawing=false;remoteLast=null;}));
    $("#remoteEraser")?.addEventListener("click",()=>{remoteErase=!remoteErase;$("#remoteEraser").textContent=remoteErase?"Pen":"Eraser";});
    $("#remoteClear")?.addEventListener("click",()=>{remoteCtx?.clearRect(0,0,remoteCanvas.width,remoteCanvas.height);});
    window.addEventListener("resize",resizeRemoteCanvas);
  }
  $("#sendText")?.addEventListener("click",()=>toast("Text sending will be enabled after phone pairing is built."));
  const updateClock=()=>{
    const now=new Date();
    if($("#liveDate")) $("#liveDate").textContent=now.toLocaleDateString(undefined,{weekday:"long",day:"numeric",month:"long",year:"numeric"});
    if($("#utilityClock")) $("#utilityClock").textContent=now.toLocaleTimeString();
  };
  updateClock(); setInterval(updateClock,1000);

  // Basic keyboard navigation for TV remotes.
  document.addEventListener("keydown", e => {
    if(mode!=="tv" || ["INPUT","TEXTAREA"].includes(document.activeElement?.tagName)) return;
    if(e.key==="Escape" || e.key==="Backspace"){ location.href="./"; return; }
    const focusable=[...document.querySelectorAll(".side-link,button,a[href],.tool-button")].filter(el=>!el.disabled && el.offsetParent!==null);
    const current=focusable.indexOf(document.activeElement);
    if(["ArrowDown","ArrowRight","ArrowUp","ArrowLeft"].includes(e.key)){
      e.preventDefault(); const delta=(e.key==="ArrowDown"||e.key==="ArrowRight")?1:-1;
      focusable[(current+delta+focusable.length)%focusable.length]?.focus();
    }
    if(e.key==="Enter" && document.activeElement?.matches(".side-link,.tool-button")) document.activeElement.click();
  });

  // Hash shortcuts on the home screen open the TV workspace.
  if(mode==="home" && location.hash){ location.href="?mode=tv"+location.hash; }
  if(mode==="tv" && location.hash){
    const target=location.hash.slice(1);
    const map={whiteboard:"boardPanel",presentation:"presentationPanel",learning:"learningPanel",utilities:"utilitiesPanel",files:"filesPanel"};
    const panel=map[target];
    if(panel){ const btn=$(`.side-link[data-panel="${panel}"]`); btn?.click(); }
  }
})();
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
}
